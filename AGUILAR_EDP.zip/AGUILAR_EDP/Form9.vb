﻿Imports MySql.Data.MySqlClient

Public Class Form9
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Call Connect_to_DB()
        Dim mycmd As New MySqlCommand

        Dim name As String = usernametxt.Text
        Dim password As String = passwordtxt.Text
        Dim first_name As String = firstnametxt.Text
        Dim last_name As String = lastnametxt.Text
        Dim address As String = addresstxt.Text
        Dim email As String = emailtxtx.Text

        Dim sql As String = "INSERT INTO users (username, password, first_name, last_name, address, email) VALUES (@name, @password, @first_name, @last_name, @address, @email)"
        mycmd = New MySqlCommand(sql, myconn)

        mycmd.Parameters.AddWithValue("@name", name)
        mycmd.Parameters.AddWithValue("@password", password)
        mycmd.Parameters.AddWithValue("@first_name", first_name)
        mycmd.Parameters.AddWithValue("@last_name", last_name)
        mycmd.Parameters.AddWithValue("@address", address)
        mycmd.Parameters.AddWithValue("@email", email)
        mycmd.ExecuteNonQuery()
        MessageBox.Show("Account Successfully Created!", "Successful", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Call Disconnect_to_DB()
        Form1.Show()
        Hide()
    End Sub
End Class